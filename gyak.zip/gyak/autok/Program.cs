﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace autok
{
    internal class Program
    {
        //1-es feladat
        public class autok
        {
            public string rendszam;
            public int ora;
            public int perc;
            public int sebesseg;

        }
        static void Main(string[] args)
        {
            //1-es feladat
            List<autok> list = new List<autok>();
            using (StreamReader sr = new StreamReader("jeladas.txt"))
            {
                while (!sr.EndOfStream)
                {
                    autok auto = new autok();
                    string[] sor = sr.ReadLine().Split('\t');
                    auto.rendszam= sor[0];
                    auto.ora=Convert.ToInt32(sor[1]);
                    auto.perc= Convert.ToInt32(sor[2]);
                    auto.sebesseg= Convert.ToInt32(sor[3]);
                    list.Add(auto);
                }
            }
            //2. feladat
            int db = list.Count;
            Console.WriteLine("2.feladat");
            Console.WriteLine($"Az utolsó jeladás időpontja {list[db-1].ora}:{list[db - 1].perc} a jármű rendszáma {list[db - 1].rendszam}");
            //3. feladat
            Console.WriteLine("3.feladat");
            Console.WriteLine($"Az első jármű: {list[0].rendszam}");
            Console.Write("Jeladások időpontjai: ");
            for (int i = 0; i < db; i++)
            {
                if (list[0].rendszam == list[i].rendszam)
                {
                    Console.Write($"{list[i].ora}:{list[i].perc} ");
                }
            }
            Console.WriteLine();
            //4.feladat
            Console.WriteLine("4.feladat");
            Console.Write("Kérem adja meg az órát ");
            int beora = Convert.ToInt32(Console.ReadLine());

            Console.Write("Kérem adja meg az percet ");
            int beperc = Convert.ToInt32(Console.ReadLine());
            

            int talalt = 0;
            for (int i = 0;i < db; i++)
            {
                if (beora == list[i].ora && beperc == list[i].perc) talalt++;
            }
            Console.WriteLine($"A jeladások száma: {talalt}");

            //5. feladat
            Console.WriteLine("5.feladat");
            int maxi = 0;

            for(int i = 0;i< db ; i++)
            {
                if(maxi < list[i].sebesseg) maxi = list[i].sebesseg;
            }
            Console.WriteLine($"A legnagyobb sebesség km/h: {maxi} ");
            Console.Write("A járművek: ");
            for(int i = 0; i< db ; i++)
            {
                if (maxi == list[i].sebesseg) Console.Write($"{list[i].rendszam} ");
            }
            Console.WriteLine();
            //6.feladat
            Console.WriteLine("6.feladat");
            Console.Write("Kérem, adja meg a rendszámot: ");

            List<autok> keresett = new List<autok>();
            string rendbe = Console.ReadLine();

            for (int i = 0; i < db ; i++)
            {
                if (rendbe == list[i].rendszam) keresett.Add(list[i]);
            }
            Console.WriteLine($"{list[0].ora}:{list[0].perc} 0.0 km");
            double ossztav = 0;

            for (int i = 0; i < keresett.Count; i++)
            {
                double perc = (keresett[i].ora + 60 + keresett[i - 1].ora * 60 + keresett[i - 1].perc);
                double tav = perc / 60 * keresett[i - 1].sebesseg;
                ossztav += tav;

                Console.WriteLine($"{keresett[i].ora}:{keresett[i].perc} {Math.Round(ossztav)} km");
            }

            // 7. feladat
            List<string> rendszamok = new List<string>();

            for (int i = 0; i < db; i++)
            {
                if (rendszamok.Contains(list[i].rendszam)) rendszamok.Add(list[i].rendszam);
            }

            int kezdora = 0;
            int kezdperc = 0;
            int vegora = 0;
            int vegperc = 0;
            bool elso = true;

            for (int j = 0; j < db; j++)
            {
                if (rendszamok[j] == list[j].rendszam)
            }

            Console.ReadKey();
        }
    }
}
