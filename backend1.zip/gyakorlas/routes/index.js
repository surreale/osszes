var express = require('express');
var router = express.Router();
var Db = require('../db/dboperation');

/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('index', { title: 'Express' });
});

router.get('/api/megye', async function(req, res) {
  const megyek = await Db.selectMegye();
  res.json(megyek);
});

router.get('/api/megye/:rekordId', async function(req, res) {
  try {
    let id = req.params.rekordId;
    const megyek = await Db.selectMegyeId(id);
    console.log(megyek.length);
    if (megyek.length == 0) {
      res.status(404).json({hiba:"Nincs ilyen rekord!"});
    }
    else {
      res.json(megyek);
    }
  }
  catch {
    res.status(500).json({hiba:"Belső szerver hiba!"});
  }
});

module.exports = router;
