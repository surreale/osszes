var config = require('./dbconfig');
const sql = require('mysql2/promise');
let pool = sql.createPool(config);

async function selectMegye() {
    try {
        let [rows] = await pool.query('SELECT * FROM megye');
        return rows;
    }
    catch (error) {
        throw error;
    }
}

async function selectMegyeId(id) {
    try {
        let [rows] = await pool.query('SELECT * FROM megye WHERE cty_id = ?', [id]);
        return rows;
    }
    catch (error) {
        throw error;
    }
}

async function deleteMegye(id) {
    try {
        let [rows] = await pool.query('DELETE FROM megye WHERE cty_id = ?', [id]);
        return rows;
    }
    catch (error) {
        throw error;
    }
}

async function insertMegye(data) {
    try {
        let [rows] = await pool.query('INSERT INTO megye (cty_code, cty_name) values (?, ?)', [data.cty_code, data.cty_name]);
        return rows;
    }
    catch (error) {
        throw error;
    }
}

module.exports = {
    selectMegye,
    selectMegyeId,
    deleteMegye,
    insertMegye
}