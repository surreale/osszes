var express = require('express');
var router = express.Router();
var Db = require('../db/dboperations');

/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('index', { title: 'Express' });
});

router.get('/megyek', async function(req, res) {
  //res.send('Megyék...');
  try {
    const megyek = await Db.selectMegye();
    res.json(megyek);
  }
  catch {
    res.status(500).json({Hiba: 'Belső szerver hiba'});
  }
});

router.get('/megyek/:id', async function(req, res) {
  const id = req.params.id;
  const megye = await Db.selectMegyeId(id);

  if (megye.length === 0) {
    res.status(404).json(megye);
  } else {
    res.json(megye);
  }
});

router.delete('/megyek/:id', async function(req, res) {
  const id = req.params.id;
  const megye = await Db.deleteMegye(id);
  res.json(megye);
});

router.post('/megyek', async function(req, res) {
  let data = req.body;
  const eredmeny = await Db.insertMegye(data);
  res.json(eredmeny);
});

module.exports = router;
