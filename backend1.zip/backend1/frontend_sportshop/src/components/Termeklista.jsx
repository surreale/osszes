import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Container, Row, Col, Card, Button } from 'react-bootstrap';

export default function Termeklista() {

    /*
    const termekek = [
        {'name' : 'alma', 'ar': 200 },
        {'name' : 'körte', 'ar': 450}, 
        {'name' : 'barack', 'ar': 820}
    ];*/

    const [data, setData] = useState([]); // Adattárolásra

    // adatkérés a Backend-től
    async function fetchData() {
        const response = await axios.get('http://localhost:8080/termek');
        setData(response.data);
    }

    // Adatbetöltés - a komponens létrejöttekor fut le
    useEffect(() => {
        fetchData();
    }, []);

    return (
        <div>
            <h1>Sportshop - terméklista</h1>
            <Container fluid>
            <Row>

            {data.map(
                (elem) => (
                      <Col xs={12} sm={6} md={4} lg={3} key={elem.azonosito} className="d-flex justify-content-center my-3">
                          <Card >
                            <Card.Img variant="top" src={'/img/'+elem.kepnev}  />
                            <Card.Body>
                              <Card.Title>{elem.termek}</Card.Title>
                              <Card.Text>
                                This is a longer card with supporting text below as a natural
                                lead-in to additional content. This content is a little bit
                                longer.
                              </Card.Text>
                              <Button>Kosárba</Button>
                            </Card.Body>
                          </Card>
                        </Col>
                    )
            )}
            
          </Row>
          </Container>

        </div>
    );
}