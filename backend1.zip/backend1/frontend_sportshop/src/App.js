import logo from './logo.svg';
import './App.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import Termeklista from './components/Termeklista';

function App() {
  return (
    <div className="App">
       <Termeklista />
    </div>
  );
}

export default App;
