import logo from './logo.svg';
import './App.css';
import 'bootstrap/dist/css/bootstrap.min.css'; 
import {BrowserRouter as Router, Routes, Route} from 'react-router-dom';
import Nyitolap from './components/Nyitolap';
import Termeklista from './components/Termeklista';

function App() {
  return (
    <Router>
      <Routes>
         <Route index element={<Nyitolap />} />
         <Route path="/termeklista" element={<Termeklista />} />
      </Routes>
    </Router>
  );
}

export default App;
