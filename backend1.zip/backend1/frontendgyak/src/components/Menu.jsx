import {Container,Nav,Navbar,NavDropdown} from 'react-bootstrap';

export default function Menu() {

    return (
        <Navbar expand="lg" className="bg-body-tertiary">
            <Container>
                <Navbar.Brand href="#home">Gyakoló App</Navbar.Brand>
                <Navbar.Toggle aria-controls="basic-navbar-nav" />
                <Navbar.Collapse id="basic-navbar-nav">
                    <Nav className="me-auto">
                        <Nav.Link href="/">Nyitólap</Nav.Link>
                        <Nav.Link href="/termeklista">Terméklista</Nav.Link>
                        <NavDropdown title="Felhasználók" id="basic-nav-dropdown">
                            <NavDropdown.Item href="#action/3.1">Regisztáció</NavDropdown.Item>
                            <NavDropdown.Item href="#action/3.2">Bejelentkezés</NavDropdown.Item>
                            <NavDropdown.Divider />
                            <NavDropdown.Item href="#action/3.4">Kijelentkezés</NavDropdown.Item>
                        </NavDropdown>
                    </Nav>
                </Navbar.Collapse>
            </Container>
        </Navbar>
    )
}