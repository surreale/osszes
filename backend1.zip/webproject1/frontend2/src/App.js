import './App.css';
import Nyitolap from './components/Nyitolap';

function App() {
  return (
    <Nyitolap/>
  );
}

export default App;
