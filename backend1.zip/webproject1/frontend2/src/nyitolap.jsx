import Menu from "./Menu";
import Footer from "./Footer";

    function Nyitolap() {
        return (
          <div>
            <Menu />
                <h1>Saját projekt címe</h1>
                <p>Ez az én projektem</p>
            <Footer />
          </div>
        );
      }