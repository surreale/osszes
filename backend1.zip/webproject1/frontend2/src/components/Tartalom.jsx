export default function Tartalom(){
    return(
        <div>
         <h1>Saját projekt címe</h1>
         <p>Ez az én projektem</p>
        </div>
    )
}