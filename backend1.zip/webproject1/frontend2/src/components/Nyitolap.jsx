//import Menu from "./Menu";
import Footer from "./Footer";
//import Tartalom from "./Tartalom";
//import TermekLista from "./TermekLista";
import About from "./About";
import Fomenu from "./Fomenu/Fomenu";

function Nyitolap(){
  return(
    <Fomenu/>
  )    
}

export default Nyitolap;