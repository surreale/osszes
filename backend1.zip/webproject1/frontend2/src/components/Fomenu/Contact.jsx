import React from "react";

export default function Contact() {
    return (
        <div>
            <h1>Kapcsolat</h1>
            <h2>Telefon: +0 123-4567</h2>
            <h2>e-Mail: spn@contact.com</h2>
            <h2>Location: 2482 Seedörfl, Münchendorfer Straße 71.</h2>
        </div>
    )
}