import React from "react";
import logo from './jabba.webp';

export default function About() {
    return (
        <div>
            <h1>Bemutatkozó oldal - Rólunk</h1>
            <img src={logo} alt="" />

            <p>Lorem ipsum dolor sit amet, quidam persius suscipit te est. Iudicabit concludaturque et qui. Est ut vivendum reformidans, an his nonumes intellegat. An aliquip discere laoreet est. Et sed prompta consequuntur, vix et novum aeque sanctus. Fugit abhorreant mea ea. At purto eirmod scripserit sit, ad has hinc fierent reprimique.

Fierent disputationi ex his. Fastidii oportere expetenda cu sit, lobortis aliquando ex sed. An mea verear oportere, in bonorum consequat mel, elit scripta sadipscing ex mei. Modus virtute percipitur te sit. In ius dicit delectus, hinc facilis cu sed. Ex qui utinam lucilius adipiscing, eu quod vero quaeque has.

Mel ea accusata tractatos. Nec cu eius homero liberavisse. Possim probatus consequat per cu, vix vivendo atomorum ex. Et facer aliquid appareat his.

Habemus suscipit duo ad, quo propriae postulant gloriatur ea. Democritum adversarium at per. Vero sanctus periculis ei ius, id inermis pericula accommodare sea, nisl recusabo convenire mea an. Ad sed dico consequuntur. No sit dolor salutandi, vix ut tollit doming aliquip, te modo intellegat mel.

Impetus maiestatis eos no, utinam vivendo expetenda te sed, cu per prima mutat. Pri vocent referrentur complectitur no, sed ei purto accusamus philosophia, at mea hinc elit oblique. Velit labore id pro, corrumpit percipitur neglegentur ea nam. Te sumo impetus ius. Vim tritani integre consetetur ad. Quo unum fugit dictas at, putent quodsi necessitatibus vix cu, eum sint delicata incorrupte id.</p>
        </div>
    )
}