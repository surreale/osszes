export default function Menu() {
    return (
        <div style={{backgroundColor: "silver"}}>
            Menüsor
        </div>
    )
}