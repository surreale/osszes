export const cars = [
    { id: 1, marka:'Ford', modell: 'Mustang', evjarat: 2020, kep: "mustang.webp" },
    { id: 2, marka:'Audi', modell: 'A6', evjarat: 2010, kep: "a6.jpg" },
    { id: 3, marka:'BMW', modell: 'X5', evjarat: 2019, kep: "x5.jpg" },
    { id: 4, marka:'Opel', modell: 'Astra', evjarat: 2011, kep: "astra.jpg" },
    { id: 5, marka:'Renault', modell: 'Trafic', evjarat: 2013, kep: "trafic.png" }
];