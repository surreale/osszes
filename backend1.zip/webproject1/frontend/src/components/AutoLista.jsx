import React from "react";
import {cars} from "../data/cardata";

function AutoKartya({auto}) {
    return (
        <div>
            <div>Márka: {auto.marka}</div>
            <div>Modell: {auto.modell}</div>
            <div>Évjárat: {auto.evjarat}</div>
            <img src={"/img/" + auto.kep} alt="" width={300} id="img" />
            <hr />
        </div>
    )
}

    function AutoLista() {
    return (
        <div>
            <h1>Autók listája</h1>
            {cars.map((car) => <AutoKartya auto = {car} />)}
        </div>
    )
}

export default AutoLista;