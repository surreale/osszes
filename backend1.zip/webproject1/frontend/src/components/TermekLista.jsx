import React from "react";
import { products } from "../data/products.js";

function TermekLista() {
    return (
        <div>
            <h1>Termékek</h1>
            {products.map (
                (termek) => (
                <div>
                <h2 key = {termek.id}> {termek.title} </h2>
                <img src={termek.image} alt="kép" style={{width: 150}} />
                <h3>Ár: {termek.price} $</h3>
                <p>{termek.description}</p>
                </div>
                )
            )
            }
        </div>
    );
}

export default TermekLista;