﻿using System.IO;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace BarlangokGUI
{
    public partial class MainWindow : Window
    {
        List<Barlang> list = new List<Barlang>();
        int hosszusag = 0;
        int melyseg = 0;
        int hely = 0;
        public MainWindow()
        {
            InitializeComponent();

            using (StreamReader sr = new StreamReader("barlangok.txt"))
            {
                while (!sr.EndOfStream)
                {
                    sr.ReadLine();
                    string sor;

                    while ((sor = sr.ReadLine()) != null)
                    {
                        list.Add(new Barlang(sor));
                    }
                }
            }
        }

        private void mentes_Click(object sender, RoutedEventArgs e)
        {
            int aktHosszusag = Convert.ToInt32(hossz.Text);
            int aktMelyseg = Convert.ToInt32(mely.Text);

            if (hosszusag > aktHosszusag) MessageBox.Show($"A hossz nem lehet kisebb a korábbi értéknél.{aktHosszusag}");
            else list[hely].Hossz = aktHosszusag;
            if (melyseg > aktMelyseg) MessageBox.Show($"A mélység nem lehet kisebb a korábbi értéknél.{aktMelyseg}");
            else list[hely].Melyseg = aktMelyseg;
            azon.Text = "";
            nev.Content = $"Barlang neve: ";
            hossz.Text = "";
            mely.Text = "";
        }

        private void keres_Click(object sender, RoutedEventArgs e)
        {
            int azonosito = Convert.ToInt32(azon.Text);
            bool van = false;

            for (int i = 0; i < list.Count(); i++)
            {
                if (list[i].Azon == azonosito)
                {
                    nev.Content = $"Barlang neve: {list[i].Nev}";
                    hossz.Text = Convert.ToString(list[i].Hossz);
                    mely.Text = Convert.ToString(list[i].Melyseg);
                    mentes.IsEnabled = true;
                    van = true;
                    break;
                }
            }

            if (!van)
            {
                MessageBox.Show("Ezzel az azonosítóval nem létezik barlang!");
                azon.Text = "";
                nev.Content = "Barlang neve: ";
                hossz.Text = "";
                mely.Text = "";
                mentes.IsEnabled = false;
            }
        }
    }
}